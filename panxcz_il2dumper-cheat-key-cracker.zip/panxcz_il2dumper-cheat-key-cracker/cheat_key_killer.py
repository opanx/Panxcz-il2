#!/usr/bin/env python3
"""
cheat_key_killer.py – Hapus validasi key pada script .sh / ELF cheat Android
Mode:
  1) Offline: modifikasi file langsung (hapus prompt key, fake sukses)
  2) Online: mulai fake server lokal untuk merespon request key dengan "valid"
Usage:
  python cheat_key_killer.py <file.sh / elf> [--mode online|offline]
"""

import sys
import os
import re
import shutil
import subprocess
import argparse
from contextlib import suppress

try:
    from pwn import *
except ImportError:
    print("[!] Install pwntools dulu: pip install pwntools")
    sys.exit(1)

def crack_shell_script(path, mode='offline'):
    """Patch script .sh agar tidak meminta key."""
    with open(path, 'r') as f:
        content = f.read()

    # Backup
    shutil.copy2(path, path + ".bak")

    # Pattern umum: read -p "key:" key, atau echo -n "Enter key"
    # Ganti dengan key kosong (atau key pancingan)
    # Cari blok if [ "$key" != "..." ] dan hapus atau set selalu true
    # 1. Hapus baris 'read' yang terkait key
    content_new = re.sub(r'^\s*read\s+-p?\s*["\'].*key.*["\']?\s+\w+', '# KEY REMOVED', content, flags=re.MULTILINE)

    # 2. Cari perbandingan if [ "$x" != "hardcoded_key" ] untuk diubah jadi if false (always skip)
    content_new = re.sub(r'if\s+\[\s*"\$(\w+)"\s*!=\s*"[^"]*"\s*\];\s*then', r'if false; then # KEY BYPASSED', content_new)

    # 3. Alternatif: jika ada pemanggilan program validasi, ganti dengan exit 0
    content_new = content_new.replace('verify_key', '# verify_key dihapus')

    # 4. Hilangkan sleep/exit jika key salah
    content_new = re.sub(r'(sleep\s+\d+|exit\s+\d+)\s*\n\s*fi', r'fi   # KEY OK', content_new)

    # 5. Mode online: tambahkan di awal script untuk fetch key dari server palsu
    if mode == 'online':
        # Sisipkan curl ke localhost:1337/validate
        online_hack = '''
KEY=$(curl -s http://localhost:1337/validate || echo "valid_key")
if [ "$KEY" != "valid_key" ]; then
    echo "Key server not available, using default"
    KEY="valid_key"
fi
'''
        # Carlah titik sebelum validasi kunci, sisipkan di sana (simplifikasi: di awal)
        content_new = online_hack + content_new

    # 6. Kadang ada validasi md5sum / shasum, kita bypass
    content_new = re.sub(r'if\s+\[\s*"\$\(echo\s+.*?\)"\s*!=\s*"[^"]*"\s*\];', r'if false; then', content_new)

    with open(path, 'w') as f:
        f.write(content_new)
    print(f"[+] Script {path} dipatch.")

def crack_elf_binary(path, mode='offline'):
    """Patch binary ELF: NOP-kan strcmp atau ret 1 pada fungsi validasi."""
    elf = ELF(path)

    # Cari fungsi yang mencurigakan (misal: check_key, verify, license)
    candidates = []
    for sym in elf.symbols:
        if 'key' in sym.name.lower() or 'verify' in sym.name.lower() or 'license' in sym.name.lower():
            if sym.size > 0:
                candidates.append(sym)

    if not candidates:
        # Jika tidak ketemu, lakukan pencocokan string 'invalid key' di data
        data_section = elf.get_section_by_name('.rodata')
        if data_section:
            data = data_section.data()
            # Cari string "Invalid key" atau "Wrong key"
            for m in re.finditer(b'(?i)(invalid|wrong|bad).*key', data):
                addr = m.start() + data_section.header.sh_addr
                print(f"[*] Kemungkinan string kunci di alamat: {hex(addr)}")
                # Cek referensi ke string tersebut untuk menemukan fungsi validasi
        # Fallback manual: patch fungsi umum yang membandingkan input dengan hardcode.
        # Kita gunakan heuristik: cari instruksi "bl strcmp" lalu patch branch setelahnya.
        # Simulasi sederhana: cari "strcmp" di PLT, lalu NOP instruksi kondisional setelahnya.
        strcmp_plt = elf.plt.get('strcmp')
        if strcmp_plt:
            print(f"[*] strcmp@plt di {hex(strcmp_plt)} – akan dipatch semua pemanggilnya")
            # Baca seluruh kode .text
            text_section = elf.get_section_by_name('.text')
            if text_section:
                code = text_section.data()
                # Cari "bl strcmp" pattern (ARM64: 0x94000000 + offset)
                # Patching dilakukan manual; alternatif gunakan objcopy.
                # Untuk simplicity, kita buat script terpisah dengan radare2.

    # Gunakan radare2 untuk patching otomatis (jika tersedia)
    if shutil.which('r2'):
        print("[*] Menggunakan radare2 untuk patching...")
        # Buat script r2
        r2script = """\
aaa
?e Memeriksa fungsi terkait key...
/at strcmp
?e Patching semua pemanggilan strcmp menjadi mov x0,1; ret
"""
        # Lebih sederhana: patch fungsi entry yang memanggil strcmp, ubah menjadi langsung return 1.
        # Untuk demo, asumsikan fungsi validasi ada di alamat tertentu (user bisa masukkan manual)
        # Kita berikan opsi manual override.
        manual_addr = input("[?] Alamat fungsi validasi (hex) [enter untuk skip]: ").strip()
        if manual_addr:
            r2cmd = f'r2 -w -q -e io.cache=true -c "s {manual_addr}; wa mov x0,1; ret; q" {path}'
            subprocess.run(r2cmd, shell=True)
            print(f"[+] Fungsi di {manual_addr} di-patch menjadi return 1.")
        else:
            print("[!] Tidak bisa patch tanpa alamat. Kamu bisa gunakan Ghidra/IDA untuk mencari fungsi verifikasi.")
            print("    Setelah ditemukan, jalankan: r2 -w -c 's ALAMAT; wa mov x0,1; ret; q' file_elf")
    else:
        print("[!] radare2 tidak ditemukan. Install r2 atau gunakan metode manual.")
    # Backup
    shutil.copy2(path, path + ".bak")

def start_fake_server():
    """Mulai server HTTP sederhana untuk merespon key validation (mode online)."""
    from http.server import HTTPServer, BaseHTTPRequestHandler
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            if "/validate" in self.path:
                self.send_response(200)
                self.send_header("Content-type", "text/plain")
                self.end_headers()
                self.wfile.write(b"valid_key")
            else:
                self.send_response(404)
                self.end_headers()
        def do_POST(self):
            self.do_GET()
    server = HTTPServer(('localhost', 1337), Handler)
    print("[*] Fake key server running on http://localhost:1337/validate")
    print("    Buka terminal lain, jalankan cheat, server akan mengembalikan 'valid_key'.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.shutdown()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('target', help='File .sh atau ELF binary')
    parser.add_argument('--mode', choices=['offline','online','server'], default='offline',
                        help='offline: patch file, online: sisipkan fake client, server: jalankan server palsu')
    args = parser.parse_args()

    if args.mode == 'server':
        start_fake_server()
        return

    if not os.path.exists(args.target):
        print(f"[-] File {args.target} tidak ada")
        return

    if args.target.endswith('.sh'):
        crack_shell_script(args.target, args.mode)
    else:
        crack_elf_binary(args.target, args.mode)

if __name__ == '__main__':
    main()

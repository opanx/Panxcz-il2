// bypass.c - Library bypass anti-dump (LD_PRELOAD style)
#include <stdio.h>
#include <string.h>
#include <dlfcn.h>
#include <unistd.h>
#include <sys/ptrace.h>
#include <android/log.h>
#define TAG "Bypass"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

int ptrace(int request, ...) {
    if (request == PTRACE_TRACEME) return 0;
    // return original
    static int (*real_ptrace)(int, ...) = NULL;
    if (!real_ptrace) real_ptrace = dlsym(RTLD_NEXT, "ptrace");
    va_list args; va_start(args, request);
    pid_t pid = va_arg(args, pid_t);
    void *addr = va_arg(args, void*);
    void *data = va_arg(args, void*);
    va_end(args);
    return real_ptrace ? real_ptrace(request, pid, addr, data) : -1;
}

FILE *fopen(const char *pathname, const char *mode) {
    static FILE *(*real_fopen)(const char*, const char*) = NULL;
    if (!real_fopen) real_fopen = dlsym(RTLD_NEXT, "fopen");
    if (pathname && strstr(pathname, "/proc/self/status")) {
        LOGI("Blocked fopen on %s", pathname);
        return NULL;
    }
    return real_fopen(pathname, mode);
}

ssize_t read(int fd, void *buf, size_t count) {
    static ssize_t (*real_read)(int, void*, size_t) = NULL;
    if (!real_read) real_read = dlsym(RTLD_NEXT, "read");
    ssize_t ret = real_read(fd, buf, count);
    if (ret > 0 && memmem(buf, ret, "TracerPid:", 10)) {
        char *start = (char*)memmem(buf, ret, "TracerPid:", 10);
        if (start) {
            int orig_line_len = strchr(start, '\n') - start + 1;
            char fake[] = "TracerPid:\t0\n";
            memmove(start + strlen(fake), start + orig_line_len, ret - (start - (char*)buf) - orig_line_len);
            memcpy(start, fake, strlen(fake));
            ret = strlen(fake) + (ret - orig_line_len);
            LOGI("TracerPid spoofed");
        }
    }
    return ret;
}

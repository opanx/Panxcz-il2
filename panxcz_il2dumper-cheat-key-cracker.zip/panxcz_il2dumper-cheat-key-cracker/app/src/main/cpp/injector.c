// injector.c - Injeksi library via ptrace (sederhana)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <android/log.h>
#define TAG "Injector"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

int main(int argc, char *argv[]) {
    if (argc != 4) { LOGE("Usage: %s <pid> <lib_path> <func>", argv[0]); return 1; }
    pid_t pid = atoi(argv[1]);
    LOGI("Attaching to %d", pid);
    if (ptrace(PTRACE_ATTACH, pid, NULL, NULL) == -1) {
        LOGE("ptrace attach failed"); return 1;
    }
    waitpid(pid, NULL, 0);
    // ⚠️ Bagian injeksi penuh (panggil remote dlopen + dlsym) terlalu panjang,
    // tetapi kamu bisa menggunakan tool seperti `magiskproc` atau `frida`.
    // Di sini kita lakukan injeksi sederhana lewat `/proc/pid/mem` dengan bantuan shell:
    char cmd[1024];
    snprintf(cmd, sizeof(cmd),
        "echo '%s' | /system/bin/sh -c 'cat > /proc/%d/mem' 2>&1", argv[2], pid);
    system(cmd);
    ptrace(PTRACE_DETACH, pid, NULL, NULL);
    return 0;
}

// dumper.c - Dump metadata & libil2cpp.so via process_vm_readv
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/uio.h>
#include <stdint.h>
#include <android/log.h>
#define TAG "Dumper"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static const uint32_t MAGIC = 0xAF1BA1FA;

ssize_t process_vm_readv_custom(pid_t pid, void *src, void *dst, size_t len) {
    struct iovec local = { .iov_base = dst, .iov_len = len };
    struct iovec remote = { .iov_base = src, .iov_len = len };
    return process_vm_readv(pid, &local, 1, &remote, 1, 0);
}

int main(int argc, char *argv[]) {
    if (argc != 3) { LOGE("Usage: %s <pid> <out_dir>", argv[0]); return 1; }
    pid_t pid = atoi(argv[1]);
    const char *out_dir = argv[2];

    // Buka /proc/pid/maps
    char maps_path[128];
    snprintf(maps_path, sizeof(maps_path), "/proc/%d/maps", pid);
    FILE *fp = fopen(maps_path, "r");
    if (!fp) { LOGE("Cannot open %s", maps_path); return 1; }

    char line[1024];
    unsigned long meta_start = 0, meta_end = 0;
    unsigned long lib_start  = 0, lib_end  = 0;

    // Cari region libil2cpp.so (untuk dump file .so)
    rewind(fp);
    while (fgets(line, sizeof(line), fp)) {
        unsigned long start, end;
        char path[256] = {0};
        if (sscanf(line, "%lx-%lx %*s %*x %*x:%*x %*d %255s", &start, &end, path) < 2) continue;
        if (strstr(path, "libil2cpp.so")) {
            lib_start = start; lib_end = end;
            break;
        }
    }

    // Cari metadata magic
    rewind(fp);
    while (fgets(line, sizeof(line), fp)) {
        unsigned long start, end;
        char perms[5], path[256] = {0};
        if (sscanf(line, "%lx-%lx %4s %*x %*x:%*x %*d %255s", &start, &end, perms, path) < 3) continue;
        if (perms[0] != 'r') continue;
        size_t size = end - start;
        if (size < 0x100000 || size > 0x10000000) continue; // 1MB - 256MB
        uint8_t *buf = malloc(size);
        if (!buf) continue;
        ssize_t n = process_vm_readv_custom(pid, (void*)start, buf, size);
        if (n <= 0) { free(buf); continue; }
        for (size_t i = 0; i < n - 4; i += 8) {
            if (*(uint32_t*)(buf + i) == MAGIC) {
                LOGI("Magic at 0x%lx", start + i);
                // Simpan metadata
                char out[512];
                snprintf(out, sizeof(out), "%s/global-metadata.dat", out_dir);
                FILE *f = fopen(out, "wb");
                if (f) { fwrite(buf, 1, size, f); fclose(f); LOGI("Saved %s", out); }
                free(buf);
                meta_start = start; meta_end = end;
                goto found_meta;
            }
        }
        free(buf);
    }
found_meta:
    fclose(fp);

    // Dump libil2cpp.so
    if (lib_start && lib_end) {
        size_t sz = lib_end - lib_start;
        uint8_t *lbuf = malloc(sz);
        if (lbuf) {
            ssize_t n = process_vm_readv_custom(pid, (void*)lib_start, lbuf, sz);
            if (n > 0) {
                char out[512];
                snprintf(out, sizeof(out), "%s/libil2cpp.so", out_dir);
                FILE *f = fopen(out, "wb");
                if (f) { fwrite(lbuf, 1, n, f); fclose(f); LOGI("Saved %s", out); }
            }
            free(lbuf);
        }
    } else {
        // Fallback: copy dari disk
        FILE *maps = fopen(maps_path, "r");
        while (fgets(line, sizeof(line), maps)) {
            if (strstr(line, "libil2cpp.so")) {
                char *p = strchr(line, '/');
                if (p) {
                    char *e = strchr(p, '\n'); if (e) *e = 0;
                    char dest[512];
                    snprintf(dest, sizeof(dest), "%s/libil2cpp.so", out_dir);
                    FILE *src = fopen(p, "rb");
                    FILE *dst = fopen(dest, "wb");
                    if (src && dst) {
                        uint8_t tmp[4096]; size_t r;
                        while ((r = fread(tmp, 1, 4096, src)) > 0) fwrite(tmp, 1, r, dst);
                        fclose(src); fclose(dst);
                        LOGI("Copied %s", dest);
                    }
                }
                break;
            }
        }
        fclose(maps);
    }

    return 0;
}

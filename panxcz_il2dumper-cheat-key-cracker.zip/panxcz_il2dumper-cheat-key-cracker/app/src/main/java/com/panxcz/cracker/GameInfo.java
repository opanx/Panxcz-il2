package com.panxcz.dumper;

public class GameInfo {
    public int pid;
    public String packageName;
    public String processName;

    @Override
    public String toString() {
        return packageName + " (PID:" + pid + ")";
    }
}

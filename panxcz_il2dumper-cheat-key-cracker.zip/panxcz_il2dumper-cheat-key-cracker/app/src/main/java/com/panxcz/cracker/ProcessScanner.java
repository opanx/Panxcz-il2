package com.panxcz.dumper;

import com.topjohnwu.superuser.Shell;
import java.util.ArrayList;
import java.util.List;

public class ProcessScanner {
    public static List<GameInfo> scanIL2CPPGames() {
        List<GameInfo> list = new ArrayList<>();
        try {
            // Jalankan grep untuk mencari process yang memuat libil2cpp.so
            Shell.Result r = Shell.getShell().newJob()
                .add("grep -l libil2cpp.so /proc/*/maps 2>/dev/null | cut -d'/' -f3 | sort -u")
                .exec();
            for (String pidStr : r.getOut().toString().split("\n")) {
                pidStr = pidStr.trim();
                if (pidStr.isEmpty()) continue;
                int pid = Integer.parseInt(pidStr);
                GameInfo info = readGameInfo(pid);
                if (info != null) list.add(info);
            }
        } catch (Exception e) { /* ignore */ }
        return list;
    }

    private static GameInfo readGameInfo(int pid) {
        try {
            Shell.Result cmd = Shell.getShell().newJob()
                .add("cat /proc/" + pid + "/cmdline | tr '\\0' ' '")
                .exec();
            String full = cmd.getOut().toString().trim();
            // Ambil package name
            String pkg = full.replaceAll("^.*?([a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+).*$", "$1");
            if (pkg.isEmpty() || !pkg.contains(".")) {
                pkg = full; // fallback
            }
            GameInfo info = new GameInfo();
            info.pid = pid;
            info.packageName = pkg;
            info.processName = full;
            return info;
        } catch (Exception e) { return null; }
    }
}

package com.panxcz.dumper;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.topjohnwu.superuser.Shell;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    private ListView listGames;
    private Button btnScan;
    private ProgressBar progress;
    private TextView statusText;
    private GameListAdapter adapter;
    private ArrayList<GameInfo> gameList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listGames = findViewById(R.id.list_games);
        btnScan = findViewById(R.id.btn_scan);
        progress = findViewById(R.id.progress_bar);
        statusText = findViewById(R.id.status_text);
        adapter = new GameListAdapter(this, gameList);
        listGames.setAdapter(adapter);

        btnScan.setOnClickListener(v -> {
            Shell.getShell(shell -> {
                if (shell.isRoot()) scanGames();
                else showToast("Root akses gagal!");
            });
        });

        Shell.getShell(shell -> {
            if (shell.isRoot()) showToast("Root OK");
        });
    }

    private void scanGames() {
        progress.setVisibility(View.VISIBLE);
        statusText.setText("Scanning...");
        new Thread(() -> {
            List<GameInfo> list = ProcessScanner.scanIL2CPPGames();
            runOnUiThread(() -> {
                gameList.clear();
                gameList.addAll(list);
                adapter.notifyDataSetChanged();
                progress.setVisibility(View.GONE);
                statusText.setText("Ditemukan " + list.size() + " game");
            });
        }).start();
    }

    public void onGameClick(GameInfo game) {
        new DumperTask(this, game).execute();
    }

    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}

package com.panxcz.dumper;

import android.content.Context;
import android.view.*;
import android.widget.*;
import java.util.List;

public class GameListAdapter extends ArrayAdapter<GameInfo> {
    private Context ctx;
    private List<GameInfo> items;

    public GameListAdapter(Context context, List<GameInfo> objects) {
        super(context, R.layout.list_item_game, objects);
        ctx = context; items = objects;
    }

    @Override
    public View getView(int i, View v, ViewGroup parent) {
        if (v == null) v = LayoutInflater.from(ctx).inflate(R.layout.list_item_game, parent, false);
        TextView txt = v.findViewById(R.id.text_game_name);
        txt.setText(items.get(i).toString());
        v.setOnClickListener(__ -> ((MainActivity)ctx).onGameClick(items.get(i)));
        return v;
    }
}

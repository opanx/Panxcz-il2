package com.panxcz.dumper;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;
import com.topjohnwu.superuser.Shell;
import java.io.*;

public class DumperTask extends AsyncTask<Void, String, Boolean> {
    private Context ctx;
    private GameInfo game;
    private String outBase;

    public DumperTask(Context ctx, GameInfo game) {
        this.ctx = ctx;
        this.game = game;
        this.outBase = "/sdcard/Panxcz_Dumps/" + game.packageName + "/";
    }

    @Override
    protected void onPreExecute() {
        Toast.makeText(ctx, "Dump " + game.packageName + "...", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected Boolean doInBackground(Void... v) {
        try {
            // 1. Siapkan direktori output
            Shell.getShell().newJob().add("mkdir -p " + outBase).exec();

            // 2. Ekstrak bypass library dan inject ke proses target
            File bypass = extractAsset("bypass_lib.so", "/data/local/tmp/libbypass.so");
            if (bypass == null) return false;
            String injector = ctx.getApplicationInfo().nativeLibDir + "/libinjector.so";
            Shell.Result res1 = Shell.getShell().newJob()
                .add("chmod 755 " + injector)
                .add(injector + " " + game.pid + " " + bypass.getAbsolutePath() + " init")
                .exec();
            publish("Inject: " + res1.getOut());

            // 3. Dump dengan native dumper
            String dumper = ctx.getApplicationInfo().nativeLibDir + "/libdumper.so";
            Shell.Result res2 = Shell.getShell().newJob()
                .add("chmod 755 " + dumper)
                .add(dumper + " " + game.pid + " " + outBase)
                .exec();
            publish("Dump: " + res2.getOut());

            // 4. Jalankan Il2CppDumper ARM64 untuk menghasilkan .cs
            File il2cppBin = extractAsset("Il2CppDumper_ARM64", "/data/local/tmp/Il2CppDumper");
            if (il2cppBin == null) return false;
            String csDir = outBase + "cs_output/";
            Shell.Result res3 = Shell.getShell().newJob()
                .add("mkdir -p " + csDir)
                .add("chmod 755 " + il2cppBin.getAbsolutePath())
                .add(il2cppBin.getAbsolutePath() + " " + outBase + "libil2cpp.so " + outBase + "global-metadata.dat " + csDir)
                .exec();
            publish("Decompile: " + res3.getOut());

            // 5. Verifikasi hasil
            File tf = new File(csDir);
            if (tf.exists() && tf.list().length > 0) {
                publish("Sukses! File .cs di " + csDir);
                return true;
            }
            publish("Gagal, tidak ada file .cs");
            return false;
        } catch (Exception e) {
            publish("Error: " + e.getMessage());
            return false;
        }
    }

    private File extractAsset(String assetName, String destPath) {
        try {
            InputStream in = ctx.getAssets().open(assetName);
            FileOutputStream out = new FileOutputStream(destPath);
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
            out.close();
            in.close();
            return new File(destPath);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private void publish(String msg) {
        publishProgress(msg);
    }

    @Override
    protected void onProgressUpdate(String... values) {
        Toast.makeText(ctx, values[0], Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPostExecute(Boolean ok) {
        Toast.makeText(ctx, ok ? "Selesai!" : "Dump gagal", Toast.LENGTH_LONG).show();
    }
}

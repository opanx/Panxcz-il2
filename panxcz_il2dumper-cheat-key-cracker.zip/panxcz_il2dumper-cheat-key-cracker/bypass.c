arm-linux-androideabi-gcc -shared -fPIC -o bypass_lib.so bypass.c -ldl
